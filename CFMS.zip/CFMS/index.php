<?php
include('functions.php');
if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>College Fest Management System</title>
    <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

</head>
<body>
  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#intro" class="scrollto"><img src="img/logo.png" alt="VYRO LOGO" title=""></a>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="index.php">Home</a></li>
		      <li><a href="#about">About</a></li>
          <li><a href="event.php">Events</a></li>
          <li><a href="schedule.php">Schedule</a></li>
          <li><a href="gallery.php">Gallery</a></li>
          <li><a href="sponsors.php">Sponsors</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li class="buy-tickets"><a href="index.php?logout='1'">logout</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container wow fadeIn">
      <h1 class="mb-4 pb-0">VYRO <br> 2021</h1>
      <p class="mb-4 pb-0">02-15, Bhiwandi Rd, Vasai-Virar, Maharashtra 401208 </p>
      <a href="https://youtu.be/2Bp8T2fBihY" class="venobox play-btn mb-4" data-vbtype="video"
        data-autoplay="true"></a>
      <a href="#about" class="about-btn scrollto">About The Event</a>
    </div>
  </section>

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2>About The Event</h2>
            <p>VYRO is one of its kind as it has Technical as well as non-technical events. Around 30 different events from Computer, I.T., Civil, Electronics and Telecommunication department are a part of VYRO. Students get exposure of the technical field and get a chance to enhance their knowledge. Students from various colleges across Mumbai, Thane and Palghar district are invited to participate. VYRO is the signature event of Universal College of Engineering. It has a reach of more than 2000 students. VYRO has a social media reach of 3000+ viewers combined across various social media platforms. It is rightly said that each one of us learns through errors. Keeping this in mind, our college gives a free hand to students to host this event and commit mistakes and learn from the same. Our aim is that the students learn the lessons of leadership, team work, team building, working in challenging circumstances, hospitality and endless is the list of learning.</p>
          </div>
          <div class="col-lg-3">
            <h3>Where</h3>
            <p>Universal College Of Engineering</p>
          </div>
          <div class="col-lg-3">
            <h3>When</h3>
            <p>15th February, 2021</p>
          </div>
        </div>
      </div>
    </section>

    <!--==========================
      F.A.Q Section
    ============================-->
    <section id="faq" class="wow fadeInUp">

      <div class="container">

        <div class="section-header">
          <h2>F.A.Q </h2>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-9">
              <ul id="faq-list">

                <li>
                  <a data-toggle="collapse" class="collapsed" href="#faq1">  Where can I register for a particular event? <i class="fa fa-minus-circle"></i></a>
                  <div id="faq1" class="collapse" data-parent="#faq-list">
                    <p>
                      The registration desks have been setup in the front portion of our campus and you can register yourself for solo as well as group events that you're interested in and you can also enquire about other events from the registration desk committee.
                    </p>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq2" class="collapsed"> When will the Events of VYRO commence? <i class="fa fa-minus-circle"></i></a>
                  <div id="faq2" class="collapse" data-parent="#faq-list">
                    <p>
                      All the details regarding Events that will take place during VYRO technical fest has been properly listed down in the 'Schedule' section of our website for the ease of users. For more information, please visit the 'Schedule' section of our website.
                    </p>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq3" class="collapsed"> Whats the theme for this year's VYRO fest? <i class="fa fa-minus-circle"></i></a>
                  <div id="faq3" class="collapse" data-parent="#faq-list">
                    <p>
                      VYRO has always welcomed the curiosity of our fellow students and with such young and talented minds working for this fest, they came up with the theme of 'AVENEGERS' for our Fest this year.
                    </p>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq4" class="collapsed"> Will there be transportation services for the students coming from different colleges? <i class="fa fa-minus-circle"></i></a>
                  <div id="faq4" class="collapse" data-parent="#faq-list">
                    <p>
                     Yes. There will be Bus Facility for college students coming from various colleges and a particular location will be decided for pickup-and-drop services that mainly rounds up with most of the student's campus area.
                    </p>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq5" class="collapsed"> Will the students be provided any certificates if they win or participate in a particular event ? <i class="fa fa-minus-circle"></i></a>
                  <div id="faq5" class="collapse" data-parent="#faq-list">
                    <p>
                      OFCOURSE! They will be provided with certificates on the spot and there is no need to worry about not getting any certificates as 'Participation Certificates' will also be provided to the participants.
                    </p>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq6" class="collapsed"> Why the Universal College's biggest fest name is called 'VYRO'? <i class="fa fa-minus-circle"></i></a>
                  <div id="faq6" class="collapse" data-parent="#faq-list">
                    <p>
                      VYRO stands for :<br>
                      V : Very large Integration <br>
                      Y : Yielding Opportunities <br>
                      R : Recursive <br>
                      O : Open Source. <br>
                      In order to sum up this defination, our Biggest Fest 'VYRO' gives the students an opportunity to take part in various events irrespective of their stream and course and allow them to indulge into a bigger platform of learning through entertainment and fun.
                    </p>
                  </div>
                </li>
      
              </ul>
          </div>
        </div>

      </div>

    </section>


  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="img/logo.png" alt="VYRO LOGO">
            <p><br>VYRO means
              <br>
              V- Very large Integration
              <br>
              Y- Yielding Opportunities
              <br>
              R- Recursive
              <br>
              O- Open Source.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="index.php">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="index.php#about">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="contact.php">Contact Us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="index.php#faq">FAQs</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="https://universalcollegeofengineering.edu.in/">College Website</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Near Bhajansons & Punyadham Kaman,<br> Bhiwandi Rd, Vasai-Virar,<br> Maharashtra 401208<br>
              <strong>Phone:</strong> +91 080070 00755<br>
              <strong>Email:</strong><a href="mailto: vyro2021@gmail.com"> vyro2021@gmail.com</a><br>
            </p>

            <div class="social-links">
              <a href="https://twitter.com/itsa_ucoe" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="https://www.facebook.com/UCoEKaman/" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="https://www.instagram.com/ucoekaman/" class="instagram"><i class="fa fa-instagram"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Location</h4>
            <ul>
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3764.4292000202045!2d72.91444451546467!3d19.350559848311832!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7a56dd564fc65%3A0xdedc6f62731ee7eb!2sUniversal%20College%20of%20Engineering%20Mumbai!5e0!3m2!1sen!2sin!4v1606563957910!5m2!1sen!2sin" width="255" height="243" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>VYRO</strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="">Group 14</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
    
</body>
</html>