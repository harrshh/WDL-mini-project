<?php 
include('../functions.php');

if (!isAdmin()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: ../login.php');
}

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>College Fest Management System</title>
    <!-- Main Stylesheet File -->
  <link href="../css/style.css" rel="stylesheet">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="../img/favicon.png" rel="icon">
  <link href="../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="../lib/animate/animate.min.css" rel="stylesheet">
  <link href="../lib/venobox/venobox.css" rel="stylesheet">
  <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

</head>
<body>
  <!--==========================
    Header
  ============================-->
  <header id="header" class="header-fixed">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#intro" class="scrollto"><img src="../img/logo.png" alt="VYRO LOGO" title=""></a>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li><a href="index_ad.php">Home</a></li>
          <li><a href="index_ad.php#about">About</a></li>
          <li class="menu-active"><a href="event_ad.php">Events</a></li>
          <li><a href="schedule_ad.php">Schedule</a></li>
          <li><a href="create_user.php">Admin</a></li>
          <li><a href="crud.php">CRUD</a></li>
          <li><a href="gallery_ad.php">Gallery</a></li>
          <li><a href="sponsors_ad.php">Sponsors</a></li>
          <li><a href="contact_ad.php">Contact</a></li>
          <li class="buy-tickets"><a href="index_ad.php?logout='1'">logout</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

<!--==========================
  Event Details Section
============================-->
<main id="main" class="main-page">

<section id="speakers-details" class="wow fadeIn">
  <div class="container">
    <div class="section-header">
      <h2>Event Details</h2>
      <p>Here are the highlights of the following Events</p>
    </div>

    <div class="row">
      <div class="col-md-6">
        <img src="../img/speakers/2.jpg" alt="Event Summary" class="img-fluid">
      </div>

      <div class="col-md-6">
        <div class="details">
          <h2>Gaming Events</h2>

          <p>Voluptatem perferendis sed assumenda voluptatibus. Laudantium molestiae sint. Doloremque odio dolore dolore sit. Quae labore alias ea omnis ex expedita sapiente molestias atque. Optio voluptas et.</p>

          <p>Aboriosam inventore dolorem inventore nam est esse. Aperiam voluptatem nisi molestias laborum ut. Porro dignissimos eum. Tempore dolores minus unde est voluptatum incidunt ut aperiam.</p> 

          <p>Et dolore blanditiis officiis non quod id possimus. Optio non commodi alias sint culpa sapiente nihil ipsa magnam. Qui eum alias provident omnis incidunt aut. Eius et officia corrupti omnis error vel quia omnis velit. In qui debitis autem aperiam voluptates unde sunt et facilis.</p>
        </div>
      </div>
      
    </div>
  </div>

</section>

</main>

 <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="../img/logo.png" alt="VYRO LOGO">
            <p><br>VYRO means
              <br>
              V- Very large Integration
              <br>
              Y- Yielding Opportunities
              <br>
              R- Recursive
              <br>
              O- Open Source.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="index_ad.php">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="index_ad.php#about">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="contact_ad.php">Contact Us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="index_ad.php#faq">FAQs</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="https://universalcollegeofengineering.edu.in/">College Website</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Near Bhajansons & Punyadham Kaman,<br> Bhiwandi Rd, Vasai-Virar,<br> Maharashtra 401208<br>
              <strong>Phone:</strong> +91 080070 00755<br>
              <strong>Email:</strong><a href="mailto: vyro2021@gmail.com"> vyro2021@gmail.com</a><br>
            </p>

            <div class="social-links">
              <a href="https://twitter.com/itsa_ucoe" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="https://www.facebook.com/UCoEKaman/" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="https://www.instagram.com/ucoekaman/" class="instagram"><i class="fa fa-instagram"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Location</h4>
            <ul>
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3764.4292000202045!2d72.91444451546467!3d19.350559848311832!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7a56dd564fc65%3A0xdedc6f62731ee7eb!2sUniversal%20College%20of%20Engineering%20Mumbai!5e0!3m2!1sen!2sin!4v1606563957910!5m2!1sen!2sin" width="255" height="243" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>VYRO</strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="">Group 14</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="../lib/jquery/jquery.min.js"></script>
  <script src="../lib/jquery/jquery-migrate.min.js"></script>
  <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../lib/easing/easing.min.js"></script>
  <script src="../lib/superfish/hoverIntent.js"></script>
  <script src="../lib/superfish/superfish.min.js"></script>
  <script src="../lib/wow/wow.min.js"></script>
  <script src="../lib/venobox/venobox.min.js"></script>
  <script src="../lib/owlcarousel/owl.carousel.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="../contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="../js/main.js"></script>
    
</body>
</html>