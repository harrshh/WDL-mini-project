<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'cfmsdb');

    // initialize variables
    $timing = "";
	$name = "";
	$detail = "";
    $id = 0;
    $update = false;

	if (isset($_POST['save'])) {
        $timing = $_POST['timing'];
		$name = $_POST['name'];
		$detail = $_POST['detail'];

		mysqli_query($db, "INSERT INTO crud (timing, name, detail) VALUES ('$timing', '$name', '$detail')"); 
		$_SESSION['message'] = "Details of the Event have been saved"; 
		header('location: crud.php');
    }
    
    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $timing = $_POST['timing'];
        $name = $_POST['name'];
        $detail = $_POST['detail'];
    
        mysqli_query($db, "UPDATE crud SET timing='$timing', name='$name', detail='$detail' WHERE id=$id");
        $_SESSION['message'] = "Address updated!"; 
        header('location: crud.php');
    }

    if (isset($_GET['del'])) {
        $id = $_GET['del'];
        mysqli_query($db, "DELETE FROM crud WHERE id=$id");
        $_SESSION['message'] = "Address deleted!"; 
        header('location: schedule_ad.php');
    }